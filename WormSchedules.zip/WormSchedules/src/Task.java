public enum Task {
    DomeRepair(WormType.Biochemist),
    RoverRepair(WormType.MechEngineer),
    Plumbing(WormType.SpacePlumber),
    AlienClassification(WormType.XenoBiologist),
    Break(null);
    private final WormType type;

    private Task(WormType type){
        this.type = type;
    }

    public WormType getSpecializedType(){
        return type;
    }
}
