public enum WormType {
    Biochemist,
    MechEngineer,
    SpacePlumber,
    XenoBiologist;

    public Task getSpecialization() {
        switch (this) {
            case Biochemist:
                return Task.DomeRepair;
            case MechEngineer:
                return Task.RoverRepair;
            case SpacePlumber:
                return Task.Plumbing;
            case XenoBiologist:
                return Task.AlienClassification;
        }
        return Task.Break;
    }
}
