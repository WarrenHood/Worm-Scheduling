import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws Exception {
        Scanner userIn = new Scanner(System.in);
        String fileName = userIn.nextLine().trim();
        int bioChemistCount, mechEngineerCount, spacePlumberCount, xenioCount;
        Task currentTaskType;
        ArrayList<Worm> worms;
        HashMap<Task, Integer> todo = new HashMap<>();
        HashMap<Task, int[]> upcoming = new HashMap<>();

        try {
            BufferedReader fileInput = new BufferedReader(new FileReader(fileName));
            String[] currentLine;
            currentLine = fileInput.readLine().split(",");
            bioChemistCount = Integer.parseInt(currentLine[0].trim());
            mechEngineerCount = Integer.parseInt(currentLine[1].trim());
            spacePlumberCount = Integer.parseInt(currentLine[2].trim());
            xenioCount = Integer.parseInt(currentLine[3].trim());

            worms = new ArrayList<>();

            int shiftCount = 0;
            for(int i=0; i<4; i++){
                currentLine = fileInput.readLine().split(",");
                shiftCount = currentLine.length - 1;

                Task temp;
                switch (currentLine[0]) {
                    case "D":
                        temp = Task.DomeRepair;
                        break;
                    case "R":
                        temp = Task.RoverRepair;
                        break;
                    case "P":
                        temp = Task.Plumbing;
                        break;
                    case "A":
                        temp = Task.AlienClassification;
                        break;
                    default:
                        throw new Exception("Invalid input.");
                }

                int[] shifts = new int[currentLine.length - 1];
                for (int j = 1; j < currentLine.length; j++) {
                    shifts[j - 1] = Integer.parseInt(currentLine[j].trim());
                }
                upcoming.put(temp, shifts);
            }

            InitializeWorms(worms, WormType.Biochemist, bioChemistCount);
            InitializeWorms(worms, WormType.XenoBiologist, xenioCount);
            InitializeWorms(worms, WormType.MechEngineer, mechEngineerCount);
            InitializeWorms(worms, WormType.SpacePlumber, spacePlumberCount);

            todo.put(Task.AlienClassification, 0);
            todo.put(Task.DomeRepair, 0);
            todo.put(Task.Plumbing, 0);
            todo.put(Task.RoverRepair, 0);

            int minMotivation = 2;
            int maxMotivation = 35;

            for (int i = 0; i < shiftCount; i++) {
                todo.replace(Task.AlienClassification, todo.get(Task.AlienClassification) + upcoming.get(Task.AlienClassification)[i]);
                todo.replace(Task.RoverRepair, todo.get(Task.RoverRepair) + upcoming.get(Task.RoverRepair)[i]);
                todo.replace(Task.Plumbing, todo.get(Task.Plumbing) + upcoming.get(Task.Plumbing)[i]);
                todo.replace(Task.DomeRepair, todo.get(Task.DomeRepair) + upcoming.get(Task.DomeRepair)[i]);
                ArrayList<Integer> freeWormIndices = new ArrayList<Integer>();

                for(int j=0; j<worms.size(); j++){
                    //System.out.printf("Looking at worm %d\n",j);

                    // If worm is unemployed
                    if(!worms.get(j).isEmployed() || worms.get(j).getMotivation() < minMotivation){
                        //System.out.printf("Skipping worm %d as he is unemployed\n",j);
                        continue;
                    }


                    //Assign him a task he specializes in if possible
                    //System.out.println(worms.get(j).getType().getSpecialization());
                    if(todo.get(worms.get(j).getType().getSpecialization()) > 0 && worms.get(j).canTakeTask(worms.get(j).getType().getSpecialization())){
                        //System.out.printf("Giving worm %d a task\n",j);
                        worms.get(j).assignTask(worms.get(j).getType().getSpecialization());
                        todo.replace(worms.get(j).getType().getSpecialization(),todo.get(worms.get(j).getType().getSpecialization())-1);
                    }

                    // Add him to a list of free worms
                    else{
                        //System.out.printf("No specialized tasks available for worm %d\n",j);
                        freeWormIndices.add(j);
                    }


                }

                for(int wormIndex : freeWormIndices){
                    if(todo.get(Task.Plumbing) > 0 && worms.get(wormIndex).canTakeTask(Task.Plumbing)){
                        worms.get(wormIndex).assignTask(Task.Plumbing);
                        todo.replace(Task.Plumbing,todo.get(Task.Plumbing)-1);
                    }
                    else if(todo.get(Task.RoverRepair) > 0 && worms.get(wormIndex).canTakeTask(Task.RoverRepair)){
                        worms.get(wormIndex).assignTask(Task.RoverRepair);
                        todo.replace(Task.RoverRepair,todo.get(Task.RoverRepair)-1);
                    }
                    else if(todo.get(Task.DomeRepair) > 0 && worms.get(wormIndex).canTakeTask(Task.DomeRepair)){
                        worms.get(wormIndex).assignTask(Task.DomeRepair);
                        todo.replace(Task.DomeRepair,todo.get(Task.DomeRepair)-1);
                    }
                    else if(todo.get(Task.AlienClassification) > 0 && worms.get(wormIndex).canTakeTask(Task.AlienClassification)){
                        worms.get(wormIndex).assignTask(Task.AlienClassification);
                        todo.replace(Task.AlienClassification,todo.get(Task.AlienClassification)-1);
                    }
                    else {
                        break;
                    }
                }

                for(Worm currentWorm : worms){
                    currentWorm.workOnCurrentTask();
                }



            }

            for(Worm someWorm : worms){
                if(someWorm.getType() == WormType.Biochemist){
                    System.out.print("B");
                }
                else if(someWorm.getType() == WormType.MechEngineer){
                    System.out.print("M");
                }
                else if(someWorm.getType() == WormType.SpacePlumber){
                    System.out.print("S");
                }
                else if(someWorm.getType() == WormType.XenoBiologist){
                    System.out.print("X");
                }

                for(Task t : someWorm.getShiftHistory()){
                    if(t == Task.AlienClassification){
                        System.out.print("A");
                    }
                    else if(t == Task.Plumbing){
                        System.out.print("P");
                    }
                    else if(t == Task.RoverRepair){
                        System.out.print("R");
                    }
                    else if(t == Task.DomeRepair){
                        System.out.print("D");
                    }
                    else if(t == Task.Break){
                        System.out.print("F");
                    }


                }
                System.out.print("\n");
            }
        }
        catch (FileNotFoundException ex){

            System.out.println(ex.getMessage());
            ex.printStackTrace();
        }
    }

    static void InitializeWorms(ArrayList<Worm> worms, WormType t, int count) {
        for (int i = 0; i < count; i++) {
            worms.add(new Worm(t));
        }
    }
}
