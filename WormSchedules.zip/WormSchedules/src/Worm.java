import java.util.ArrayList;
import java.util.HashSet;

public class Worm {
    private WormType type;
    private int motivation = 15;
    private int consecutiveShiftsWorked = 0;
    private int consecutiveShiftsOff = 0;
    private int consecutiveNightShiftsWorked = 0;
    private int consecutiveDaysWorked = 0;
    private boolean needsWeekend = false;
    private boolean employed = true;
    private Task currentTask = Task.Break;
    private int currentTaskShiftsRemaining;
    private int shift = 1;
    private boolean hasCompletedSpecialisedTaskInCycle = false;
    private ArrayList<Task> shiftHistory = new ArrayList<Task>();
    private int currentDay = 1;
    HashSet<Integer> daysWorked = new HashSet<>();


    public Worm(WormType type){
        this.type = type;
    }

    public WormType getType(){
        return type;
    }

    public ArrayList<Task> getShiftHistory() {
        return shiftHistory;
    }

    public int getConsecutiveShiftsOff() {
        return consecutiveShiftsOff;
    }

    public void assignTask(Task task){
        currentTask = task;

        if (currentTask.getSpecializedType() == type) {
            currentTaskShiftsRemaining = 1;
        } else if (currentTask == Task.Break) {
            currentTaskShiftsRemaining = -1;
        } else {
            currentTaskShiftsRemaining = 2;
        }
    }

    public boolean canTakeTask(Task toTest) {

        if(consecutiveDaysWorked >= 2)
            return false;
        if(consecutiveNightShiftsWorked >= 2)
            return false;
        if (motivation <= 3)
            return false;
        if(motivation > 8)
            return true;

        int futureMotivation = motivation;

        if (consecutiveShiftsWorked == 2) {
            futureMotivation--;
        }

        if (consecutiveNightShiftsWorked == 4 && ((shift + 1) % 3 == 0)) {
            futureMotivation--;
        }

        if (consecutiveDaysWorked == 5) {
            return false;
        }

        return --futureMotivation >= 0;
    }

    public void workOnCurrentTask() throws Exception {
        if (!employed) {
            throw new Exception("Worm is unemployed.");
        }

        //Automatically assign break if work is done
        if (currentTaskShiftsRemaining == 0) {
            assignTask(Task.Break);
        }

        //Increments of variables based on current task
        if (currentTaskShiftsRemaining != -1) {
            consecutiveShiftsWorked++;

            if (!daysWorked.contains(currentDay)) {
                daysWorked.add(getCurrentDay());
                consecutiveDaysWorked++;
            }

            consecutiveShiftsOff = 0;
            currentTaskShiftsRemaining--;
        } else {
            consecutiveShiftsWorked = 0;
            consecutiveShiftsOff++;

            if (consecutiveShiftsOff >= 3 && isNightShift()) {
                consecutiveDaysWorked = 0;
            }
        }

        //Increase motivation if taking break / Decrease if working
        if (currentTask == Task.Break) {
            motivation++;
        } else {
            motivation--;
        }

        //Increase motivation if 3 consecutive breaks
        if (consecutiveShiftsOff % 3 == 0 && consecutiveShiftsOff > 0) {
            motivation += 2;
        }

        //Checks if specialised task has been completed based on 9-day cycle rule
        if ((shift - 1) % 9 == 0) {
            hasCompletedSpecialisedTaskInCycle = false;
        }

        //Increase motivation based on the 9-day cycle rule
        if (!hasCompletedSpecialisedTaskInCycle && isOnSpecialisedTask()) {
            hasCompletedSpecialisedTaskInCycle = true;
            motivation++;
        }

        //Decrease motivation if worked for 3 consecutive days
        if (consecutiveShiftsWorked % 3 == 0 && consecutiveShiftsWorked > 0) {
            motivation--;
        }

        //Increment for consecutive night shift counter
        if (isNightShift() && currentTask == Task.Break) {
            consecutiveNightShiftsWorked = 0;
        } else if (isNightShift() && currentTask != Task.Break) {
            consecutiveNightShiftsWorked++;
        }

        //Decrease motivation if more than 5 consecutive night shifts worked
        if (consecutiveNightShiftsWorked % 5 == 0 && consecutiveNightShiftsWorked > 0 && isNightShift()) {
            motivation--;
        }

        shiftHistory.add(currentTask);
        nextShift();

    }

    private Integer getCurrentDay() {
        return currentDay;
    }

    private boolean isOnSpecialisedTask() {
        return currentTask.getSpecializedType() == type;
    }

    private boolean isNightShift() {
        return shift % 3 == 0;
    }

    private void retire(){
        employed = false;
    }

    public Task getCurrentTask(){
        return currentTask;
    }

    public int getCurrentTaskShiftsRemaining() {
        return this.currentTaskShiftsRemaining;
    }

    public boolean isEmployed(){
        return employed;
    }

    public void incrementMotivation(int amount){
        motivation += amount;
    }

    public void decrementMotivation(int amount){
        motivation -= amount;
    }

    public boolean isInNeedOfWeekend(){
        return needsWeekend;
    }

    public int getMotivation() {
        return motivation;
    }

    public void nextShift(){
        shift++;
        if ((shift - 1) % 3 == 0) {
            currentDay++;
        }
    }

}
